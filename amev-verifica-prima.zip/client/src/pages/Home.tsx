import { useEffect, useState } from "react";
import { ArrowDown, ArrowRight, ArrowUpRight, BookOpen, Building2, Check, CheckCircle2, CircleHelp, ExternalLink, FileSearch, Globe2, Landmark, Link2, LockKeyhole, SearchCheck, ShieldAlert, WalletCards } from "lucide-react";

const steps = [
  {
    label: "Identifica", title: "Comincia dal nome vero.", lead: "Prima di fidarti di un marchio o di un consulente, raccogli i dati della persona giuridica che ti propone l'operazione.",
    checks: ["Ragione sociale completa e Paese dichiarato", "Numero di licenza e attività proposta", "Dominio del sito e recapiti usati per contattarti"],
    caution: "Annota queste informazioni per te. Qui non chiediamo IBAN, documenti o dati personali.",
    links: [{ label: "Registro delle Imprese", href: "https://www.registroimprese.it/l-anagrafe-nazionale-delle-imprese" }]
  },
  {
    label: "Verifica", title: "Cerca nel registro giusto.", lead: "Apri l'albo dell'autorità competente e confronta il soggetto, la licenza e le attività autorizzate. La sola presenza nel registro imprese non basta.",
    checks: ["Il nome legale coincide?", "La licenza riguarda proprio il servizio offerto?", "L'iscrizione è attuale e pertinente al Paese?"],
    caution: "Se un registro non mostra il soggetto, non pagare prima di chiarire tramite l'autorità. Una ricerca incompleta non è un verdetto automatico.",
    links: [{ label: "Albi CONSOB", href: "https://www.consob.it/web/consob/intermediaries" }, { label: "Albi Banca d'Italia", href: "https://www.bancaditalia.it/compiti/vigilanza/albi-elenchi/index.html" }, { label: "Registri ESMA", href: "https://www.esma.europa.eu/publications-and-data/databases-and-registers" }]
  },
  {
    label: "Confronta", title: "Escludi il clone.", lead: "Un truffatore può usare il nome e il numero di licenza di un'impresa vera. Controlla il sito e i contatti pubblicati dalla fonte primaria.",
    checks: ["Il dominio coincide con quello indicato dal regolatore, se pubblicato?", "E-mail e telefono sono quelli del registro?", "Ci sono avvisi o imitazioni segnalate?"],
    caution: "Un dominio non pubblicato non prova una truffa; un dominio somigliante è però un motivo per fermarsi e chiedere conferma tramite canali indipendenti.",
    links: [{ label: "Avvisi CONSOB", href: "https://www.consob.it/web/area-pubblica/avvisi-ai-risparmiatori" }, { label: "SEC PAUSE", href: "https://www.sec.gov/enforcement-litigation/public-alerts-unregistered-soliciting-entities" }]
  },
  {
    label: "Decidi", title: "Il pagamento è un controllo separato.", lead: "Per il bonifico verifica nell'app della tua banca la corrispondenza tra nome e IBAN. Per una ricarica a carta o wallet chiedi conferma all'emittente o al prestatore del servizio.",
    checks: ["Hai letto l'esito nome–IBAN della banca?", "Un beneficiario diverso ha una spiegazione verificata?", "Se usi carta o wallet, hai verificato il destinatario tramite il tuo PSP?"],
    caution: "Se emerge una discordanza non chiarita, fermati. Completare questa lista non certifica che un pagamento sia sicuro.",
    links: [{ label: "BCE: Verification of Payee", href: "https://www.ecb.europa.eu/paym/retail/instant_payments/html/instant_payments_regulation.en.html" }]
  }
];

const sources = [
  { icon: Landmark, name: "CONSOB", detail: "Intermediari e avvisi ai risparmiatori", href: "https://www.consob.it/web/consob/intermediaries" },
  { icon: Building2, name: "Banca d'Italia", detail: "Albi ed elenchi di vigilanza", href: "https://www.bancaditalia.it/compiti/vigilanza/albi-elenchi/index.html" },
  { icon: Globe2, name: "ESMA", detail: "Registri e banche dati europee", href: "https://www.esma.europa.eu/publications-and-data/databases-and-registers" },
  { icon: FileSearch, name: "FCA Register", detail: "Permessi e recapiti delle imprese UK", href: "https://register.fca.org.uk/s/" },
  { icon: SearchCheck, name: "FINRA BrokerCheck", detail: "Professionisti e imprese nel perimetro USA", href: "https://brokercheck.finra.org/" },
  { icon: WalletCards, name: "Banca Centrale Europea", detail: "Regole sulla verifica del beneficiario", href: "https://www.ecb.europa.eu/paym/retail/instant_payments/html/instant_payments_regulation.en.html" },
];

function Checklist() {
  const [active, setActive] = useState(0);
  const [done, setDone] = useState([false, false, false, false]);
  const current = steps[active];
  const completed = done.filter(Boolean).length;
  const markDone = () => {
    setDone((previous) => previous.map((item, index) => index === active ? true : item));
    if (active < steps.length - 1) setActive(active + 1);
  };
  return <div className="checklist-shell">
    <div className="checklist-nav"><div className="checklist-nav__head"><span>PERCORSO DI VERIFICA</span><strong>{completed} / 4</strong></div>
      <div className="progress-track"><span style={{ width: `${completed * 25}%` }} /></div>
      <div className="step-list">{steps.map((step, index) => <button key={step.label} type="button" className={`step-tab ${index === active ? "is-active" : ""}`} onClick={() => setActive(index)} aria-current={index === active ? "step" : undefined}>
        <span className="step-tab__index">{done[index] ? <Check size={17} strokeWidth={2.5} /> : String(index + 1).padStart(2, "0")}</span><span className="step-tab__label">{step.label}</span><ArrowRight size={16} aria-hidden="true" />
      </button>)}</div>
      <div className="checklist-nav__note"><LockKeyhole size={18} /><p>Nessun dato inserito o conservato. I passi spuntati restano solo in questa pagina.</p></div>
    </div>
    <div className="checklist-content" key={active}>
      <span className="step-kicker">PASSO {String(active + 1).padStart(2, "0")} / 04</span>
      <h3>{current.title}</h3><p className="step-lead">{current.lead}</p>
      <ul className="checks">{current.checks.map((check) => <li key={check}><span><Check size={15} /></span>{check}</li>)}</ul>
      <div className="step-caution"><ShieldAlert size={19} /><p>{current.caution}</p></div>
      <div className="step-resources"><span>FONTI UTILI PER QUESTO PASSO</span><div>{current.links.map((link) => <a key={link.href} href={link.href} target="_blank" rel="noopener noreferrer">{link.label}<ArrowUpRight size={15} aria-hidden="true" /></a>)}</div></div>
      <div className="step-actions"><button className="button button--dark" type="button" onClick={markDone}>{active === 3 ? "Segna come controllato" : "Segna il controllo e continua"}<ArrowRight size={18} /></button>{active > 0 && <button className="button-text" type="button" onClick={() => setActive(active - 1)}>Passo precedente</button>}</div>
      {completed === 4 && <div className="checklist-finish" role="status"><CheckCircle2 size={19} /><span>Hai percorso i quattro controlli. Non è una certificazione del pagamento: se resta un dubbio, non inviare denaro.</span><button type="button" onClick={() => { setDone([false, false, false, false]); setActive(0); }}>Ricomincia</button></div>}
    </div>
  </div>;
}

export default function Home() {
  useEffect(() => { document.title = "AMEV — Verifica prima di pagare | Guida alle fonti ufficiali"; }, []);
  return <main>
    <section className="hero" id="inizio">
      <img className="hero-art" src="/manus-storage/amev-globe-hero_c132435c.png" alt="" aria-hidden="true" />
      <div className="hero-wash" />
      <div className="container hero-content">
        <div className="hero-copy"><div className="eyebrow"><span className="eyebrow-dot" /> UNA GUIDA, NON UN BOLLINO DI SICUREZZA</div>
          <h1>Prima di pagare,<br /><em>trova la fonte</em><br />giusta.</h1>
          <p>Un percorso chiaro per verificare chi ti propone un investimento, dove cercare la licenza e quando fermarti prima di un bonifico o di una ricarica.</p>
          <div className="hero-actions"><a className="button button--lime" href="#percorso">Inizia la checklist <ArrowRight size={19} /></a><a className="hero-link" href="/rapporto">Leggi l'analisi <ArrowUpRight size={17} /></a></div>
        </div>
        <div className="hero-bottom"><span>ANALISI AMEV / 28.09.2026</span><span>SCOPRI IL PERCORSO <ArrowDown size={16} /></span></div>
      </div>
    </section>

    <section className="numbers-band" aria-label="Dati del catalogo AMEV"><div className="container numbers-band__inner">
      <div className="numbers-intro"><span className="tiny-label">IL DATASET AMEV</span><p>Un indice di partenza.<br /><strong>Non un albo di imprese.</strong></p></div>
      <div className="number-cell"><strong>239</strong><span>record geografici<br />e istituzionali</span></div><div className="number-cell"><strong>238</strong><span>homepage di autorità<br />valorizzate</span></div><div className="number-cell"><strong>215</strong><span>link di segnalazione<br />valorizzati</span></div>
    </div><div className="container numbers-footnote">Fonte: <a href="https://www.amevfirenze.it/financial_authorities_database.json" target="_blank" rel="noopener noreferrer">dataset AMEV <ArrowUpRight size={12} /></a>, esaminato il 28 settembre 2026. «Record» non significa Stati sovrani o imprese autorizzate.</div></section>

    <section className="section section--paper" id="metodo"><div className="container">
      <div className="section-heading section-heading--split"><div><div className="section-kicker">01 / CAPIRE PRIMA DI CERCARE</div><h2>Quattro controlli.<br /><em>Quattro cose diverse.</em></h2></div><p>Una bandiera può portarti all'autorità giusta. Da lì comincia la verifica: nessuna singola lista può dirti se il prossimo pagamento è sicuro.</p></div>
      <div className="layers-grid">
        <div className="layer-card"><span className="layer-card__num">01 / ORIENTAMENTO</span><Globe2 size={31} strokeWidth={1.5} /><h3>Directory di autorità</h3><p>Indica dove cercare. AMEV appartiene a questa categoria.</p><small>NON CONTIENE LO STATO DEL TUO BROKER</small></div>
        <div className="layer-card"><span className="layer-card__num">02 / AUTORIZZAZIONE</span><Landmark size={31} strokeWidth={1.5} /><h3>Registro ufficiale</h3><p>Mostra se una società è iscritta e per quali attività, nel suo perimetro.</p><small>CONTROLLA LICENZA, DATA E PRODOTTO</small></div>
        <div className="layer-card"><span className="layer-card__num">03 / SEGNALAZIONE</span><ShieldAlert size={31} strokeWidth={1.5} /><h3>Avvisi e warning</h3><p>Aiutano a riconoscere abusi e cloni già segnalati.</p><small>NESSUN AVVISO ≠ NESSUN RISCHIO</small></div>
        <div className="layer-card"><span className="layer-card__num">04 / PAGAMENTO</span><WalletCards size={31} strokeWidth={1.5} /><h3>Verifica beneficiario</h3><p>Per un bonifico, il confronto nome–IBAN si fa nella tua banca.</p><small>NON È UNA FUNZIONE DI AMEV</small></div>
      </div>
    </div></section>

    <section className="section section--checklist" id="percorso"><div className="container">
      <div className="section-heading section-heading--split"><div><div className="section-kicker">02 / UNA CHECKLIST DA USARE ORA</div><h2>Fermati un minuto.<br /><em>Controlla in quattro passi.</em></h2></div><p>Questo percorso non raccoglie dati e non emette un esito «sicuro». Ti aiuta a fare le domande giuste, nell'ordine giusto.</p></div>
      <Checklist />
    </div></section>

    <section className="payment-section"><div className="container payment-inner"><div className="payment-head"><div className="section-kicker section-kicker--light">03 / IL MOMENTO DEL PAGAMENTO</div><h2>La licenza di un'impresa<br /><em>non è il nome sul conto.</em></h2><p>Una società autorizzata e un beneficiario di pagamento sono verifiche separate. Se qualcosa non torna, interrompi l'operazione e chiedi conferma da un canale indipendente.</p></div>
      <div className="payment-cards"><div className="payment-card"><span className="payment-card__icon"><Landmark size={22} /></span><span className="tiny-label">SE INVII UN BONIFICO</span><h3>Nome + IBAN</h3><p>La <strong>Verification of Payee</strong> del tuo prestatore di servizi di pagamento confronta il nome indicato con l'identificativo del conto prima dell'autorizzazione. Vale per bonifici standard e istantanei in euro; non conferma licenza, affidabilità o assenza di frode.</p><a href="https://www.ecb.europa.eu/paym/retail/instant_payments/html/instant_payments_regulation.en.html" target="_blank" rel="noopener noreferrer">Leggi la fonte BCE <ArrowUpRight size={15} /></a></div>
        <div className="payment-card"><span className="payment-card__icon"><WalletCards size={22} /></span><span className="tiny-label">SE USI CARTA O WALLET</span><h3>Chiedi al tuo PSP</h3><p>Per ricariche a numero carta o wallet non esiste una directory pubblica che autentichi universalmente il destinatario. Contatta emittente o banca dai recapiti ufficiali. <strong>Se la ricarica avviene con bonifico verso un IBAN, usa il controllo nome–IBAN della banca.</strong></p><a href="/rapporto#bonifici-iban-carte-prepagate-cosa-puo-fare-davvero-la-verification-of-payee">Approfondisci nel rapporto <ArrowRight size={15} /></a></div></div>
      <div className="payment-warning"><ShieldAlert size={20} /><strong>Un nome diverso non prova da solo una truffa.</strong><span>È una discrepanza da spiegare e verificare prima di inviare denaro.</span></div>
    </div></section>

    <section className="section section--comparison" id="confronto"><div className="container"><div className="section-heading section-heading--split"><div><div className="section-kicker">04 / IL PANORAMA</div><h2>Non è l'unico atlante.<br /><em>È il percorso che conta.</em></h2></div><p>Esistono archivi web di ampiezza comparabile. I numeri qui sotto descrivono unità differenti: non sono una graduatoria di affidabilità né di completezza assoluta.</p></div>
      <div className="comparison-grid">
        <article className="comparison-card comparison-card--featured"><div className="comparison-card__top"><span>01 / AMEV FIRENZE</span><Link2 size={20} /></div><div className="comparison-card__metric">239 <small>record</small></div><h3>Bandiere, ricerca e percorsi multilingue.</h3><p>Un indice privato per arrivare ai siti delle autorità. Il vantaggio possibile è guidare il controllo preventivo in modo comprensibile.</p><a href="https://www.amevfirenze.it/" target="_blank" rel="noopener noreferrer">Visita AMEV <ArrowUpRight size={16} /></a></article>
        <article className="comparison-card"><div className="comparison-card__top"><span>02 / FAISAL KHAN</span><Globe2 size={20} /></div><div className="comparison-card__metric">215 <small>giurisdizioni</small></div><h3>Una mappa interattiva globale.</h3><p>La directory dichiara anche 451 regolatori. Filtra per regione e ambito; non è un registro di imprese autorizzate.</p><a href="https://faisalkhan.com/regulators" target="_blank" rel="noopener noreferrer">Esplora la mappa <ArrowUpRight size={16} /></a></article>
        <article className="comparison-card"><div className="comparison-card__top"><span>03 / PAYATLAS</span><FileSearch size={20} /></div><div className="comparison-card__metric">319 <small>schede</small></div><h3>Repertorio per pagamenti e fintech.</h3><p>Schede di regolatori filtrabili per tipologia, ambito e area. Anche qui la conferma di una licenza resta nella fonte primaria.</p><a href="https://payatlas.com/regulators" target="_blank" rel="noopener noreferrer">Vedi il repertorio <ArrowUpRight size={16} /></a></article>
      </div><p className="comparison-note"><CircleHelp size={16} /> Numeri pubblicati o ricavati dai rispettivi dataset al 28 settembre 2026. Un record, una giurisdizione e una scheda non sono equivalenti.</p>
    </div></section>

    <section className="editorial-section"><div className="container editorial-inner"><div className="editorial-visual"><img src="/manus-storage/amev-verification-still_c41cf1a7.png" alt="Bussola e schede di archivio, metafora visiva per la ricerca della fonte corretta" /></div><div className="editorial-copy"><div className="section-kicker">05 / TRASPARENZA PRIMA DELLA PROMOZIONE</div><h2>La fiducia si costruisce<br /><em>con dati verificabili.</em></h2><p>La valutazione ha trovato alcune cose da correggere prima di promuovere AMEV come strumento antifrode: la dicitura «129» rimasta in una pagina, percorsi di installazione PWA che rispondono 404 e link senza data di verifica per singolo record.</p><ul><li><Check size={17} /> Datate ogni collegamento e pubblicate un changelog.</li><li><Check size={17} /> Distinguete autorità, registri, warning e segnalazioni.</li><li><Check size={17} /> Evitate etichette come «più completo» o «sito ufficiale» se non dimostrabili.</li></ul><a className="text-link" href="/rapporto">Leggi il metodo e le evidenze <ArrowRight size={17} /></a></div></div></section>

    <section className="section section--sources" id="fonti"><div className="container"><div className="section-heading section-heading--split"><div><div className="section-kicker">06 / DOVE CONTROLLARE DAVVERO</div><h2>Vai sempre<br /><em>alla fonte primaria.</em></h2></div><p>I link qui sotto conducono a registri, autorità e documenti ufficiali. L'elenco orienta; non sostituisce la lettura del record relativo alla tua situazione.</p></div><div className="source-grid">{sources.map(({ icon: Icon, name, detail, href }) => <a className="source-card" key={name} href={href} target="_blank" rel="noopener noreferrer"><span className="source-card__icon"><Icon size={23} strokeWidth={1.7} /></span><span><strong>{name}</strong><small>{detail}</small></span><ArrowUpRight className="source-card__arrow" size={18} /></a>)}</div><div className="all-sources"><BookOpen size={19} /><span>Il dossier include 31 riferimenti, documentazione tecnica e limiti del confronto.</span><a href="/rapporto#riferimenti">Esamina tutte le fonti <ArrowRight size={16} /></a></div></div></section>

    <section className="section faq-section"><div className="container faq-inner"><div><div className="section-kicker">DOMANDE ESSENZIALI</div><h2>Prima del clic<br /><em>finale.</em></h2><p>Tre risposte brevi per non scambiare un indizio con una garanzia.</p></div><div className="faq-list">
      <details><summary>AMEV verifica se un'impresa è autorizzata?<span>+</span></summary><p>No. Ti aiuta a trovare l'autorità. Devi poi cercare l'impresa nel registro ufficiale pertinente e controllare attività, licenza, stato e recapiti.</p></details>
      <details><summary>Se non trovo avvisi, il pagamento è sicuro?<span>+</span></summary><p>No. Una lista di avvisi può essere incompleta o non ancora aggiornata. L'assenza di un warning non è un'autorizzazione né una garanzia.</p></details>
      <details><summary>AMEV può verificare il titolare di una carta o di un IBAN?<span>+</span></summary><p>No. Per un bonifico la verifica nome–IBAN è fornita dalla banca o dal PSP. Per ricariche a carta o wallet chiedi indicazioni al relativo emittente o PSP dai canali ufficiali.</p></details>
    </div></div></section>

    <section className="final-cta"><div className="container final-cta__inner"><div><span className="eyebrow"><span className="eyebrow-dot" /> IL PASSO PIÙ IMPORTANTE</span><h2>Un dubbio non chiarito?<br /><em>Non inviare denaro.</em></h2><p>Prenditi il tempo di confrontare le fonti e contatta banca o autorità attraverso recapiti che hai trovato in autonomia.</p></div><div className="final-cta__actions"><a className="button button--lime" href="#percorso">Rivedi la checklist <ArrowRight size={18} /></a><a className="button button--outline" href="/rapporto">Leggi il rapporto completo <ExternalLink size={17} /></a></div></div></section>
  </main>;
}

import { useEffect, useMemo } from "react";
import { Streamdown } from "streamdown";
import { ArrowLeft, ArrowUpRight, BookOpen, Clock3 } from "lucide-react";
import reportRaw from "@/content/amev-report.md?raw";

type Source = { number: number; url: string; title: string };
type Section = { title: string; id: string; body: string };

function slug(title: string) {
  return title.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function prepareReport(raw: string) {
  const [body, references = ""] = raw.split(/^## References\s*$/m);
  const sources: Source[] = Array.from(references.matchAll(/^\[(\d+)\]:\s+(https?:\/\/\S+)\s+"([^"]+)"/gm)).map((m) => ({ number: Number(m[1]), url: m[2], title: m[3] }));
  const sourceMap = new Map(sources.map((source) => [String(source.number), source.url]));
  const linkedBody = body.replace(/\[(\d+)\](?!\()/g, (citation, number: string) => sourceMap.has(number) ? `[${number}](${sourceMap.get(number)})` : citation);
  const parts = linkedBody.split(/^## (.+)$/gm);
  const sections: Section[] = [];
  for (let i = 1; i < parts.length; i += 2) {
    sections.push({ title: parts[i].trim(), id: slug(parts[i]), body: parts[i + 1]?.trim() ?? "" });
  }
  return { intro: parts[0].trim(), sections, sources };
}

export default function Report() {
  const { intro, sections, sources } = useMemo(() => prepareReport(reportRaw), []);
  useEffect(() => { document.title = "Analisi completa | AMEV — Verifica prima di pagare"; }, []);
  return <main className="report-page">
    <div className="report-hero">
      <div className="container report-hero__inner">
        <div className="report-hero__copy">
          <a href="/" className="text-back"><ArrowLeft size={17} /> Torna alla guida</a>
          <div className="eyebrow eyebrow--ink"><span className="eyebrow-dot" /> DOSSIER / ANALISI COMPARATIVA</div>
          <h1>Le fonti, i limiti,<br /><em>le possibilità.</em></h1>
          <p>L’analisi completa della directory AMEV, dei repertori analoghi e dell’uso corretto come strumento di orientamento antitruffa.</p>
          <div className="report-meta"><span><Clock3 size={16} /> 28 settembre 2026</span><span><BookOpen size={16} /> {sources.length} fonti e riferimenti</span></div>
        </div>
        <div className="report-hero__visual"><img src="/manus-storage/amev-verification-still_c41cf1a7.png" alt="Carte di archivio e bussola, illustrazione editoriale della verifica delle fonti" /><span>LA VERIFICA COMINCIA DALLA FONTE.</span></div>
      </div>
    </div>
    <div className="container report-layout">
      <aside className="report-aside" aria-label="Indice del rapporto">
        <div className="report-aside__sticky"><p>IN QUESTA ANALISI</p>
          <nav>{sections.map((section, index) => <a key={section.id} href={`#${section.id}`}><span>{String(index + 1).padStart(2, "0")}</span>{section.title}</a>)}<a href="#riferimenti"><span>↗</span>Fonti e riferimenti</a></nav>
          <div className="report-aside__note"><strong>Un limite fondamentale</strong><p>Una directory di autorità non identifica il titolare di un IBAN o di una carta.</p></div>
        </div>
      </aside>
      <article className="report-article">
        <div className="report-intro report-copy"><Streamdown>{intro}</Streamdown></div>
        {sections.map((section) => <section className="report-section" id={section.id} key={section.id}><div className="section-kicker">ANALISI / {String(sections.indexOf(section) + 1).padStart(2, "0")}</div><h2>{section.title}</h2><div className="report-copy"><Streamdown>{section.body}</Streamdown></div></section>)}
        <section className="report-section report-sources" id="riferimenti"><div className="section-kicker">DOCUMENTAZIONE</div><h2>Fonti e riferimenti</h2><p>Le fonti originali sono collegate direttamente. Le informazioni del dossier riflettono la verifica svolta il 28 settembre 2026; controlla lo stato attuale sui siti ufficiali.</p><ol>{sources.map((source) => <li key={source.number}><span>{String(source.number).padStart(2, "0")}</span><a href={source.url} target="_blank" rel="noopener noreferrer">{source.title}<ArrowUpRight size={15} aria-hidden="true" /></a></li>)}</ol></section>
      </article>
    </div>
    <div className="report-end"><div className="container"><span>LA PROSSIMA VERIFICA È SEMPRE ALLA FONTE.</span><a href="/#percorso">Apri la checklist <ArrowUpRight size={18} /></a></div></div>
  </main>;
}

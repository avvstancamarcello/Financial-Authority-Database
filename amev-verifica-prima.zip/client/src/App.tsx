import { lazy, Suspense } from "react";
import { Route, Switch } from "wouter";
import { Toaster } from "@/components/ui/sonner";
import ErrorBoundary from "@/components/ErrorBoundary";
import { ThemeProvider } from "@/contexts/ThemeContext";
import NotFound from "@/pages/NotFound";
import Home from "@/pages/Home";
import { SiteHeader, SiteFooter } from "@/components/SiteChrome";

const Report = lazy(() => import("@/pages/Report"));

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <SiteHeader />
        <Suspense fallback={<main className="page-loading" role="status">Caricamento del rapporto…</main>}>
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/rapporto" component={Report} />
            <Route component={NotFound} />
          </Switch>
        </Suspense>
        <SiteFooter />
        <Toaster />
      </ThemeProvider>
    </ErrorBoundary>
  );
}

import { useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";

const nav = [
  { label: "Il percorso", href: "/#percorso" },
  { label: "Il confronto", href: "/#confronto" },
  { label: "Le fonti", href: "/#fonti" },
  { label: "Rapporto", href: "/rapporto" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="site-header">
      <div className="site-header__inner container">
        <a className="brand" href="/" aria-label="AMEV, torna all'inizio">
          <span className="brand__mark" aria-hidden="true">a<span>.</span></span>
          <span className="brand__text"><strong>AMEV</strong><small>VERIFICA PRIMA</small></span>
        </a>
        <nav className="desktop-nav" aria-label="Navigazione principale">
          {nav.map((item) => <a href={item.href} key={item.label}>{item.label}</a>)}
        </nav>
        <a className="header-cta" href="https://www.amevfirenze.it/" target="_blank" rel="noopener noreferrer">
          Apri il database <ArrowUpRight size={16} aria-hidden="true" />
        </a>
        <button className="mobile-menu-toggle" type="button" aria-label={open ? "Chiudi menu" : "Apri menu"} aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(!open)}>
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
      {open && <nav id="mobile-menu" className="mobile-nav" aria-label="Navigazione mobile">
        {nav.map((item) => <a href={item.href} key={item.label} onClick={() => setOpen(false)}>{item.label}</a>)}
        <a href="https://www.amevfirenze.it/" target="_blank" rel="noopener noreferrer" onClick={() => setOpen(false)}>Apri il database <ArrowUpRight size={16} aria-hidden="true" /></a>
      </nav>}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="container footer-top">
        <div>
          <a className="brand brand--footer" href="/"><span className="brand__mark" aria-hidden="true">a<span>.</span></span><span className="brand__text"><strong>AMEV</strong><small>VERIFICA PRIMA</small></span></a>
          <p>Una guida per arrivare alle fonti ufficiali.<br />Non un certificato di sicurezza di imprese o pagamenti.</p>
        </div>
        <div className="footer-links"><span>ESPLORA</span><a href="/#percorso">Checklist</a><a href="/#confronto">Confronto</a><a href="/rapporto">Analisi completa</a></div>
        <div className="footer-links"><span>RISORSE</span><a href="https://www.amevfirenze.it/" target="_blank" rel="noopener noreferrer">Database AMEV <ArrowUpRight size={14} /></a><a href="https://www.consob.it/web/area-pubblica/avvisi-ai-risparmiatori" target="_blank" rel="noopener noreferrer">Avvisi CONSOB <ArrowUpRight size={14} /></a><a href="https://www.ecb.europa.eu/paym/retail/instant_payments/html/instant_payments_regulation.en.html" target="_blank" rel="noopener noreferrer">BCE: verifica beneficiario <ArrowUpRight size={14} /></a></div>
      </div>
      <div className="container footer-bottom"><span>Analisi informativa · 28 settembre 2026</span><span>Verifica sempre dati e autorizzazioni alla fonte primaria.</span></div>
    </footer>
  );
}
